"""
LegalEase AI - Text Sanitization and Formatting Utilities
"""

import re
from typing import List, Tuple


def sanitize_text(text: str) -> str:
    """
    Sanitize raw AI-generated text to ensure clean, consistent formatting
    across HTML, TXT, DOCX, and PDF outputs.

    - Strips markdown code-block wrappers if model generated them
    - Normalizes curly/typographic quotes to clean characters
    - Normalizes non-breaking spaces and irregular whitespace
    - Removes unnecessary excessive blank lines while preserving legal paragraph structure
    - Preserves legal numbering, headers, and bullet points
    """
    if not text:
        return ""

    content = str(text)

    # Remove outer markdown fences like ```markdown ... ``` or ```text ... ```
    content = re.sub(r"^```[a-zA-Z0-9_-]*\s*\n", "", content)
    content = re.sub(r"\n```\s*$", "", content)

    # Normalize typographic/curly single and double quotes
    quote_replacements = {
        "\u2018": "'",  # Left single quote
        "\u2019": "'",  # Right single quote
        "\u201c": '"',  # Left double quote
        "\u201d": '"',  # Right double quote
        "\u201a": "'",  # Single low quote
        "\u201e": '"',  # Double low quote
        "\u2013": "-",  # En dash
        "\u2014": "--", # Em dash
        "\u00a0": " ",  # Non-breaking space
        "\ufeff": "",   # Zero-width byte order mark
        "\u200b": "",   # Zero-width space
    }
    for orig, repl in quote_replacements.items():
        content = content.replace(orig, repl)

    # Normalize carriage returns
    content = content.replace("\r\n", "\n").replace("\r", "\n")

    # Replace runs of 3+ newlines with 2 newlines (preserve paragraph separation)
    content = re.sub(r"\n{3,}", "\n\n", content)

    # Strip trailing and leading whitespace
    return content.strip()


def parse_terms_to_table_data(terms: List[str]) -> List[Tuple[str, str]]:
    """
    Parses structured or semicolon-separated terms into (Term / Category, Details) pairs.
    Handles 'Key: Value', 'Key - Value', or standalone clauses.
    Example:
      'Payment: ₹50,000 per month' -> ('Payment', '₹50,000 per month')
      'Notice period of 30 days required' -> ('Clause 1', 'Notice period of 30 days required')
    """
    rows: List[Tuple[str, str]] = []
    for idx, term in enumerate(terms, start=1):
        clean_term = term.strip()
        if not clean_term:
            continue

        # Look for colon or dash delimiter
        if ":" in clean_term:
            parts = clean_term.split(":", 1)
            term_name = parts[0].strip()
            term_details = parts[1].strip()
        elif " - " in clean_term:
            parts = clean_term.split(" - ", 1)
            term_name = parts[0].strip()
            term_details = parts[1].strip()
        else:
            term_name = f"Term {idx}"
            term_details = clean_term

        rows.append((term_name, term_details))

    return rows
