"""LegalEase AI Backend Package"""
