"""
LegalEase AI - Document Generation, Sanitization, and Export Tests
"""

import pytest
from backend.services.txt_generator import format_txt
from backend.services.docx_generator import format_docx
from backend.services.pdf_generator import format_pdf
from backend.services.document_service import DocumentService
from backend.utils.sanitization import sanitize_text, parse_terms_to_table_data

SAMPLE_LEGAL_TEXT = """# EMPLOYMENT CONTRACT
This Agreement is entered into on 2026-10-03.

## 1. APPOINTMENT AND TERM
The Company agrees to employ the Employee for a period of 12 months.

## 2. COMPENSATION
The Employee shall receive a monthly base salary of ₹50,000.

## 3. CONFIDENTIALITY
The Employee agrees to maintain full confidentiality regarding proprietary intellectual property.

IN WITNESS WHEREOF, the parties execute this Agreement.
"""

SAMPLE_TERMS = [
    "Compensation: ₹50,000 per month",
    "Term: 12 months renewable",
    "Notice Period: 30 calendar days",
    "Confidentiality: Strict non-disclosure required",
]


def test_sanitize_text():
    """Verify sanitization strips unwanted markdown wrappers and normalizes quotes."""
    raw = '```markdown\n“This is an agreement” with ‘curly quotes’ and \u2013 dashes.\n```'
    sanitized = sanitize_text(raw)
    assert '```' not in sanitized
    assert '"This is an agreement"' in sanitized
    assert "'curly quotes'" in sanitized


def test_parse_terms_to_table_data():
    """Verify terms are parsed into key-value pairs for the Terms Table."""
    rows = parse_terms_to_table_data(SAMPLE_TERMS)
    assert len(rows) == 4
    assert rows[0][0] == "Compensation"
    assert "₹50,000" in rows[0][1]


def test_txt_export():
    """Verify TXT generation creates non-empty UTF-8 bytes containing contract terms."""
    txt_bytes = format_txt(
        text=SAMPLE_LEGAL_TEXT,
        doc_type="Employment Contract",
        terms=SAMPLE_TERMS,
    )
    assert isinstance(txt_bytes, bytes)
    assert len(txt_bytes) > 200
    decoded = txt_bytes.decode("utf-8")
    assert "EMPLOYMENT CONTRACT" in decoded
    assert "₹50,000 per month" in decoded
    assert "LegalEase" in decoded


def test_docx_export():
    """Verify DOCX generation creates valid Word document binary with correct headers."""
    docx_bytes = format_docx(
        text=SAMPLE_LEGAL_TEXT,
        doc_type="Employment Contract",
        terms=SAMPLE_TERMS,
    )
    assert isinstance(docx_bytes, bytes)
    assert len(docx_bytes) > 1000
    # Check for zip/docx header signature (PK\x03\x04)
    assert docx_bytes.startswith(b"PK\x03\x04")


def test_pdf_export():
    """Verify PDF generation creates valid PDF binary with correct header."""
    pdf_bytes = format_pdf(
        text=SAMPLE_LEGAL_TEXT,
        doc_type="Employment Contract",
        terms=SAMPLE_TERMS,
    )
    assert isinstance(pdf_bytes, bytes)
    assert len(pdf_bytes) > 1000
    # Check for PDF header signature (%PDF-)
    assert pdf_bytes.startswith(b"%PDF-")


def test_html_preview_formatting():
    """Verify HTML preview includes styled headings and Schedule A table."""
    html_preview = DocumentService.format_html_preview(
        text=SAMPLE_LEGAL_TEXT,
        doc_type="Employment Contract",
        terms=SAMPLE_TERMS,
    )
    assert "legalease-preview-container" in html_preview
    assert "EMPLOYMENT CONTRACT" in html_preview
    assert "Schedule A: Summary of Agreed Key Terms" in html_preview
    assert "₹50,000 per month" in html_preview
