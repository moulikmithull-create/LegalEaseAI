"""
LegalEase AI - Health and Diagnostics Endpoints
"""

from fastapi import APIRouter
from backend.config import GEMINI_MODEL, GEMINI_API_KEY
from backend.models.schemas import HealthResponse

router = APIRouter(tags=["Health"])


@router.get("/", summary="Root Verification Endpoint")
def read_root():
    """
    Root endpoint to verify that the LegalEase AI backend service is running.
    """
    return {"message": "LegalEase AI API is running"}


@router.get("/health", response_model=HealthResponse, summary="Service Health Check")
def health_check():
    """
    Provides health status and configuration diagnostics for Gemini AI.
    """
    return HealthResponse(
        status="healthy",
        model_configured=GEMINI_MODEL,
        api_key_configured=bool(GEMINI_API_KEY and len(GEMINI_API_KEY) > 5),
    )
