"""
LegalEase AI - Custom Exceptions and Safe Error Handling
"""

import logging
from typing import Dict, Any
from fastapi import Request
from fastapi.responses import JSONResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("LegalEase")


class LegalEaseException(Exception):
    """Base exception for LegalEase application."""
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class MissingAPIKeyError(LegalEaseException):
    """Raised when GEMINI_API_KEY is not configured."""
    def __init__(self, message: str = "Google Gemini API key is missing. Please set GEMINI_API_KEY in your .env file."):
        super().__init__(message, status_code=500)


class GeminiAPIError(LegalEaseException):
    """Raised when Gemini API request fails or times out."""
    def __init__(self, message: str = "Error communicating with Google Gemini AI. Please check your network connection or API quota."):
        super().__init__(message, status_code=502)


class DocumentGenerationError(LegalEaseException):
    """Raised when document formatting (DOCX, PDF, TXT) fails."""
    def __init__(self, message: str = "Failed to format or generate document export."):
        super().__init__(message, status_code=500)


async def legal_ease_exception_handler(request: Request, exc: LegalEaseException) -> JSONResponse:
    """Safe handler for custom domain exceptions without exposing internal details."""
    logger.error(f"Handled LegalEaseException on {request.url.path}: {exc.message}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": exc.message, "document_type": ""}
    )


async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Fallback handler to prevent raw stack trace exposure."""
    logger.exception(f"Unhandled exception on {request.url.path}: {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "An internal server error occurred while processing your legal document. Please verify your inputs and try again.",
            "document_type": ""
        }
    )
