"""LegalEase Utilities Package"""
