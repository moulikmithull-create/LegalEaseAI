"""LegalEase API Package"""
