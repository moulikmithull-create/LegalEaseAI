"""
LegalEase AI - Plain Text (TXT) Document Formatter
"""

from typing import List, Optional
from backend.config import LEGAL_DISCLAIMER


def format_txt(
    text: str,
    doc_type: str = "Legal Document",
    terms: Optional[List[str]] = None,
) -> bytes:
    """
    Formats the legal document draft as a clean, standardized UTF-8 plain text file.
    Includes document header, content, structured terms summary (if provided),
    and the standard legal disclaimer.
    """
    lines = []
    separator = "=" * 70
    sub_separator = "-" * 70

    # Header
    lines.append(separator)
    lines.append(f"  {doc_type.upper()}")
    lines.append(f"  Generated via LegalEase AI")
    lines.append(separator)
    lines.append("")

    # Main Body Content
    lines.append(text.strip())
    lines.append("")

    # Structured Terms Table / Summary (if available)
    if terms and len(terms) > 0:
        lines.append(sub_separator)
        lines.append("SUMMARY OF AGREED KEY TERMS:")
        lines.append(sub_separator)
        for idx, term in enumerate(terms, start=1):
            clean_term = term.strip()
            if clean_term:
                lines.append(f"  [{idx}] {clean_term}")
        lines.append("")

    # Footer & Disclaimer
    lines.append(sub_separator)
    lines.append("DISCLAIMER:")
    lines.append(LEGAL_DISCLAIMER)
    lines.append(sub_separator)
    lines.append("LegalEase Inc. | contact@legalease.com | All Rights Reserved.")

    full_output = "\n".join(lines)
    return full_output.encode("utf-8")
