"""
LegalEase AI - Professional PDF Document Formatter using ReportLab
"""

import io
import os
from typing import List, Optional
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image as ReportLabImage,
    KeepTogether,
    HRFlowable,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

from backend.config import DEFAULT_LOGO_PATH, LEGAL_DISCLAIMER
from backend.utils.sanitization import parse_terms_to_table_data


class NumberedCanvas(canvas.Canvas):
    """
    Two-pass canvas to dynamically compute and print 'Page X of Y'
    along with running header and footer on every page.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, page_count: int):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748B"))

        # Running Footer
        page_num_str = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(letter[0] - 54, 36, page_num_str)
        self.drawString(54, 36, "LegalEase AI Draft | Confidential & Privileged")
        self.drawString(
            54, 25,
            "Notice: AI-generated draft for review only. Does not constitute legal advice."
        )

        # Thin footer rule
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.5)
        self.line(54, 48, letter[0] - 54, 48)

        self.restoreState()


def format_pdf(
    text: str,
    doc_type: str = "Legal Document",
    terms: Optional[List[str]] = None,
    logo_bytes: Optional[bytes] = None,
) -> bytes:
    """
    Renders the legal document draft as a high-fidelity PDF with:
    - Branded logo
    - Document title
    - Numbered clauses and bold headings
    - Formatted Terms schedule table
    - Signatures block
    - Header, footer, and page numbers across all pages
    """
    buffer = io.BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=64,
    )

    styles = getSampleStyleSheet()

    # Custom Typography Styles
    title_style = ParagraphStyle(
        "LegalDocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        alignment=1,  # Center
        textColor=colors.HexColor("#0F172A"),
        spaceAfter=14,
    )

    h1_style = ParagraphStyle(
        "LegalHeading1",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#1E293B"),
        spaceBefore=12,
        spaceAfter=4,
        keepWithNext=True,
    )

    h2_style = ParagraphStyle(
        "LegalHeading2",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=10.5,
        leading=14,
        textColor=colors.HexColor("#334155"),
        spaceBefore=8,
        spaceAfter=3,
        keepWithNext=True,
    )

    body_style = ParagraphStyle(
        "LegalBody",
        parent=styles["Normal"],
        fontName="Times-Roman",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=5,
    )

    bullet_style = ParagraphStyle(
        "LegalBullet",
        parent=styles["Normal"],
        fontName="Times-Roman",
        fontSize=10,
        leading=14,
        leftIndent=18,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=4,
    )

    table_header_style = ParagraphStyle(
        "TableHeader",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9,
        leading=12,
        textColor=colors.white,
    )

    table_cell_style = ParagraphStyle(
        "TableCell",
        parent=styles["Normal"],
        fontName="Times-Roman",
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#1E293B"),
    )

    story = []

    # 1. Logo
    logo_data = None
    if logo_bytes:
        logo_data = io.BytesIO(logo_bytes)
    elif os.path.exists(DEFAULT_LOGO_PATH):
        try:
            with open(DEFAULT_LOGO_PATH, "rb") as f:
                logo_data = io.BytesIO(f.read())
        except Exception:
            logo_data = None

    if logo_data:
        try:
            img = ReportLabImage(logo_data, width=2.0 * inch, height=0.7 * inch)
            img.hAlign = "CENTER"
            story.append(img)
            story.append(Spacer(1, 10))
        except Exception:
            pass

    # 2. Title
    story.append(Paragraph(doc_type.upper(), title_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#0284C7"), spaceAfter=14))

    # 3. Main Document Clauses
    lines = text.strip().split("\n")
    has_signatures = False

    for line in lines:
        cleaned = line.strip()
        if not cleaned:
            story.append(Spacer(1, 4))
            continue

        if "SIGNATURE" in cleaned.upper() or "IN WITNESS WHEREOF" in cleaned.upper():
            has_signatures = True

        # Check line headers
        if cleaned.startswith("# "):
            story.append(Paragraph(cleaned.lstrip("#").strip(), h1_style))
        elif cleaned.startswith("## "):
            story.append(Paragraph(cleaned.lstrip("#").strip(), h2_style))
        elif cleaned.startswith("### "):
            story.append(Paragraph(cleaned.lstrip("#").strip(), h2_style))
        elif any(cleaned.startswith(f"{n}.") for n in range(1, 30)) and len(cleaned) < 80:
            story.append(Paragraph(cleaned, h1_style))
        elif cleaned.startswith("- ") or cleaned.startswith("* "):
            bullet_text = "&bull; " + cleaned[2:]
            story.append(Paragraph(bullet_text, bullet_style))
        else:
            # Escape XML entities for ReportLab Paragraph
            safe_text = (
                cleaned.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )
            story.append(Paragraph(safe_text, body_style))

    # 4. Formatted Terms Table
    if terms and len(terms) > 0:
        story.append(Spacer(1, 14))
        story.append(Paragraph("SCHEDULE A: KEY AGREEMENT TERMS", h1_style))

        terms_data = parse_terms_to_table_data(terms)
        table_rows = [
            [
                Paragraph("Agreed Provision", table_header_style),
                Paragraph("Specification / Term Details", table_header_style),
            ]
        ]

        for term_col, details_col in terms_data:
            safe_term = term_col.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            safe_det = details_col.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            table_rows.append([
                Paragraph(safe_term, table_cell_style),
                Paragraph(safe_det, table_cell_style),
            ])

        col_widths = [160, 344]
        table = Table(table_rows, colWidths=col_widths, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#F8FAFC"), colors.white]),
        ]))
        story.append(table)

    # 5. Signatures Section if not generated
    if not has_signatures:
        story.append(Spacer(1, 16))
        story.append(KeepTogether([
            Paragraph("IN WITNESS WHEREOF, the parties hereto have executed this Agreement:", h1_style),
            Spacer(1, 10),
            Table([
                [
                    Paragraph("<b>FIRST PARTY:</b><br/><br/>________________________________<br/>Authorized Signature<br/><br/>Name: ______________________<br/>Title: _______________________<br/>Date: _______________________", body_style),
                    Paragraph("<b>SECOND PARTY:</b><br/><br/>________________________________<br/>Authorized Signature<br/><br/>Name: ______________________<br/>Title: _______________________<br/>Date: _______________________", body_style),
                ]
            ], colWidths=[250, 254], style=[
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ])
        ]))

    # Build PDF with multi-page header/footer canvas
    doc.build(story, canvasmaker=NumberedCanvas)
    return buffer.getvalue()
