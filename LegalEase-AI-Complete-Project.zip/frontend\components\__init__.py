"""LegalEase Frontend Components Package"""
