"""LegalEase Models Package"""
