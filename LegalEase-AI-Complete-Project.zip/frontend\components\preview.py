"""
LegalEase AI - Document Preview & Editor Component
Renders the styled HTML document preview and inline editor controls.
"""

import base64
from typing import Optional, List
import streamlit as st
from backend.services.document_service import DocumentService


def render_preview_and_editor(
    content: str,
    doc_type: str,
    terms: Optional[List[str]] = None,
    logo_bytes: Optional[bytes] = None,
):
    """
    Renders the polished document preview and inline editor.
    """
    # Header & Edit Mode Toggle
    is_editing = st.session_state.get("is_editing", False)

    col_title, col_btn = st.columns([2, 1])
    with col_title:
        st.markdown("<div class='smart-card-title' style='margin-bottom: 0;'>📜 Document Preview</div>", unsafe_allow_html=True)
    with col_btn:
        btn_label = "❌ Close Editor" if is_editing else "✏️ Edit Draft"
        if st.button(btn_label, key="btn_toggle_editor"):
            st.session_state["is_editing"] = not is_editing
            st.rerun()

    # If Edit Mode is active, render the editor area
    if is_editing:
        st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
        edited_text = st.text_area(
            "Modify Agreement Text",
            value=st.session_state.get("edited_document", content),
            height=360,
            key="contract_editor_box",
            help="Directly refine clauses, names, amounts, or terms."
        )

        col_save, col_info = st.columns([1, 2])
        with col_save:
            if st.button("💾 Save Changes", type="primary", key="btn_save_draft"):
                st.session_state["edited_document"] = edited_text
                st.session_state["is_editing"] = False
                st.success("Draft updated successfully!")
                st.rerun()
        with col_info:
            st.caption("Saved modifications update the preview and all download formats immediately.")

    # Convert custom logo to Data URI if present
    logo_data_uri = None
    if logo_bytes:
        encoded = base64.b64encode(logo_bytes).decode("utf-8")
        logo_data_uri = f"data:image/png;base64,{encoded}"

    # Render Document Preview
    active_text = st.session_state.get("edited_document") or content
    html_preview = DocumentService.format_html_preview(
        text=active_text,
        doc_type=doc_type,
        terms=terms,
        logo_data_uri=logo_data_uri,
    )

    st.markdown("<div style='margin-top: 14px;'></div>", unsafe_allow_html=True)
    st.markdown(html_preview, unsafe_allow_html=True)
