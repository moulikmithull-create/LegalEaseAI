"""
LegalEase AI - POST /generate Endpoint Tests
"""

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient
from backend.main import app
from backend.utils.error_handler import GeminiAPIError, MissingAPIKeyError

client = TestClient(app)

MOCK_GENERATED_DOC = """# EMPLOYMENT CONTRACT
This Employment Agreement is entered into on 2026-10-03 between ABC Corp ("Employer") and Jane Doe ("Employee").

1. POSITION AND DUTIES
The Employee shall serve in the capacity of Senior Engineer.

2. COMPENSATION
The Employee shall receive a monthly base salary of ₹50,000.

3. CONFIDENTIALITY
The Employee agrees to maintain confidential all proprietary trade secrets.

IN WITNESS WHEREOF, the parties execute this Agreement.
"""


def test_generate_endpoint_success():
    """Verify POST /generate returns 200 and drafted content when generator succeeds."""
    payload = {
        "document_type": "Employment Contract",
        "parties": "Employer: ABC Corp\nEmployee: Jane Doe",
        "terms": [
            "Monthly salary: ₹50,000",
            "Notice period: 30 days",
            "Confidentiality required"
        ],
        "agreement_date": "2026-10-03",
        "effective_date": "2026-10-05",
        "start_date": "2026-10-05",
        "end_date": "2027-10-04"
    }

    with patch(
        "backend.ai_core.gemini_generator.GeminiDocumentGenerator.generate_document",
        return_value=MOCK_GENERATED_DOC
    ):
        response = client.post("/generate", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["document_type"] == "Employment Contract"
        assert "EMPLOYMENT CONTRACT" in data["content"]
        assert data["terms_count"] == 3


def test_generate_endpoint_missing_fields():
    """Verify POST /generate returns 422 Unprocessable Entity when required fields are missing."""
    invalid_payload = {
        "document_type": "",
        "parties": "",
    }
    response = client.post("/generate", json=invalid_payload)
    assert response.status_code == 422


def test_generate_endpoint_ai_failure():
    """Verify POST /generate handles Gemini API failure gracefully with clear error message."""
    payload = {
        "document_type": "Freelance Contract",
        "parties": "Client: Corp, Contractor: Developer",
        "terms": ["Deliverable: Website", "Payment: $2000"],
        "agreement_date": "2026-10-03",
        "effective_date": "2026-10-05",
    }

    with patch(
        "backend.ai_core.gemini_generator.GeminiDocumentGenerator.generate_document",
        side_effect=GeminiAPIError("Gemini API connection error.")
    ):
        response = client.post("/generate", json=payload)
        assert response.status_code == 502
        data = response.json()
        assert data["success"] is False
        assert "Gemini API connection error." in data["error"]


def test_generate_endpoint_missing_api_key():
    """Verify POST /generate handles missing API key gracefully."""
    payload = {
        "document_type": "General Agreement",
        "parties": "Party A and Party B",
        "terms": ["Terms apply"],
        "agreement_date": "2026-10-03",
        "effective_date": "2026-10-05",
    }

    with patch(
        "backend.ai_core.gemini_generator.GeminiDocumentGenerator.generate_document",
        side_effect=MissingAPIKeyError()
    ):
        response = client.post("/generate", json=payload)
        assert response.status_code == 500
        data = response.json()
        assert data["success"] is False
        assert "API key is missing" in data["error"]
