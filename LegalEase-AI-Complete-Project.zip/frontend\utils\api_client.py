"""
LegalEase AI - Frontend API Client
Manages all HTTP communication between Streamlit and the FastAPI backend.
"""

import os
import requests
from typing import Tuple, Optional, Dict, Any

DEFAULT_BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000").rstrip("/")


class LegalEaseAPIClient:
    """
    Robust API client with timeout protection, safe error messages,
    and automatic serialization for FastAPI endpoints.
    """

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = (base_url or DEFAULT_BACKEND_URL).rstrip("/")

    def check_health(self) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
        """
        Verify backend connectivity and return (is_healthy, message, data).
        """
        try:
            resp = requests.get(f"{self.base_url}/health", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                return True, "Backend service is operational.", data
            else:
                return False, f"Backend returned unexpected status code: {resp.status_code}", None
        except requests.exceptions.ConnectionError:
            return False, "Cannot connect to the LegalEase backend at " + self.base_url + ". Ensure the backend server is running.", None
        except requests.exceptions.Timeout:
            return False, "Backend health check timed out.", None
        except Exception as e:
            return False, f"Unexpected connection error: {str(e)}", None

    def generate_document(self, payload: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
        """
        Send document generation payload to POST /generate.
        Returns (success, error_message, response_data).
        """
        url = f"{self.base_url}/generate"
        try:
            resp = requests.post(url, json=payload, timeout=60)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success", False):
                    return True, None, data
                else:
                    return False, data.get("error", "Document generation failed."), None
            else:
                try:
                    error_json = resp.json()
                    detail = error_json.get("error") or error_json.get("detail") or "Server returned an error."
                    if isinstance(detail, list):
                        detail = "; ".join([d.get("msg", str(d)) for d in detail])
                    return False, str(detail), None
                except Exception:
                    return False, f"Backend server returned HTTP {resp.status_code}.", None

        except requests.exceptions.ConnectionError:
            return False, f"Connection to backend failed at {url}. Please make sure the FastAPI server is running on port 8000.", None
        except requests.exceptions.Timeout:
            return False, "The AI document generation request timed out after 60 seconds. Please try again with fewer terms.", None
        except Exception as e:
            return False, f"Network error during document generation: {str(e)}", None
