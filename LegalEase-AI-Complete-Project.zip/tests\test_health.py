"""
LegalEase AI - Health and Root Endpoint Tests
"""

import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_root_endpoint():
    """Verify that GET / returns successful message."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "LegalEase AI API is running" in data["message"]


def test_health_endpoint():
    """Verify that GET /health returns service status."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data.get("status") == "healthy"
    assert "model_configured" in data
    assert "api_key_configured" in data
