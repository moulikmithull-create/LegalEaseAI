"""LegalEase Frontend Package"""
