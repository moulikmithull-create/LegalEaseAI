"""
LegalEase AI - Gemini AI Document Generation Engine
"""

import os
import logging
from typing import List, Optional, Union
from backend.config import GEMINI_API_KEY, GEMINI_MODEL, LEGAL_DISCLAIMER
from backend.utils.sanitization import sanitize_text
from backend.utils.error_handler import MissingAPIKeyError, GeminiAPIError

logger = logging.getLogger("LegalEase.GeminiGenerator")


class GeminiDocumentGenerator:
    """
    Core AI generation service using Google Gemini to draft professional,
    customized, structured legal agreements and contracts.
    """

    def __init__(self, api_key: Optional[str] = None, model_name: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY or os.getenv("GEMINI_API_KEY", "").strip()
        self.model_name = model_name or GEMINI_MODEL or os.getenv("GEMINI_MODEL", "gemini-flash-latest").strip()
        self._client = None
        self._sdk_type = None

        if self.api_key:
            self._init_client()

    def _init_client(self):
        """Initialize Google GenAI client, supporting both google-genai and google-generativeai."""
        try:
            # First attempt: modern google-genai SDK
            from google import genai
            self._client = genai.Client(api_key=self.api_key)
            self._sdk_type = "google-genai"
            logger.info("Initialized Gemini with google-genai SDK.")
            return
        except ImportError:
            pass

        try:
            # Fallback attempt: google-generativeai SDK
            import google.generativeai as legacy_genai
            legacy_genai.configure(api_key=self.api_key)
            self._client = legacy_genai.GenerativeModel(self.model_name)
            self._sdk_type = "google-generativeai"
            logger.info("Initialized Gemini with google-generativeai SDK.")
            return
        except Exception as e:
            logger.error(f"Failed to initialize Gemini SDK client: {e}")
            raise GeminiAPIError(f"Failed to initialize Gemini client: {str(e)}")

    def build_prompt(
        self,
        document_type: str,
        parties: str,
        terms: Union[List[str], str],
        agreement_date: str,
        effective_date: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> str:
        """Constructs an exhaustive, legally structured prompt for Gemini."""

        if isinstance(terms, list):
            terms_formatted = "\n".join(f"- {t}" for t in terms)
        else:
            terms_formatted = "\n".join(f"- {t.strip()}" for t in terms.split(";") if t.strip())

        dates_summary = f"Agreement Date: {agreement_date}\nEffective Date: {effective_date}"
        if start_date:
            dates_summary += f"\nTerm Start Date: {start_date}"
        if end_date:
            dates_summary += f"\nTerm End Date: {end_date}"

        prompt = f"""You are an expert legal document drafting assistant.
Your task is to generate a comprehensive, professional, structured legal document DRAFT titled "{document_type}".

### CRITICAL DRAFTING INSTRUCTIONS:
1. PURPOSE: Generate a formal legal agreement draft based strictly on the user-provided parties, terms, and dates.
2. ACCURACY: Do not invent false factual claims or fabricate specific statutory citations, court names, or case precedents.
3. PLACEHOLDERS: Where necessary legal details (such as specific governing state/jurisdiction or registered entity addresses) are omitted by the user, insert clear bracketed placeholders such as [State/Jurisdiction] or [Registered Business Address].
4. STRUCTURE: Follow standard formal contract conventions:
   - Full Document Title (e.g. {document_type.upper()})
   - Execution Date & Preamble / Effective Date
   - Parties Identification Clause (clearly stating individual/entity names, roles, and definitions)
   - Recitals / Whereas Clauses (background and intent)
   - Numbered Substantive Clauses (e.g., 1. Definitions, 2. Scope & Obligations, 3. Financial & Payment Terms, 4. Term & Termination, 5. Confidentiality, 6. Intellectual Property, 7. Representations & Warranties, 8. Indemnification & Liability, 9. Dispute Resolution & Governing Law, 10. Miscellaneous)
   - Formal Signature Block with lines for signatures, printed names, titles, and dates for all parties.
5. INTEGRATION OF KEY TERMS:
   Incorporate every user-specified term accurately and expand them into complete, enforceable, professional legal provisions.
6. TONE & JARGON: Formal, precise legal drafting English suitable for business and contractual transactions.
7. OUTPUT FORMAT: Return clean plaintext with standard headings and paragraph breaks. Do NOT enclose the entire document inside markdown backtick fences (```).

### USER-PROVIDED CONTRACT SPECIFICATIONS:
Document Type: {document_type}

Parties Involved:
{parties}

Key Terms & Conditions:
{terms_formatted}

Dates & Milestones:
{dates_summary}

Draft the complete, comprehensive legal agreement now:"""

        return prompt

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: Union[List[str], str],
        agreement_date: str,
        effective_date: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> str:
        """
        Invokes Google Gemini to generate the customized legal document text,
        then sanitizes the resulting output.
        """
        # Ensure API key is configured
        if not self.api_key:
            # Refresh from environment if recently updated
            self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
            if not self.api_key:
                raise MissingAPIKeyError()
            self._init_client()

        if not self._client:
            self._init_client()

        prompt = self.build_prompt(
            document_type=document_type,
            parties=parties,
            terms=terms,
            agreement_date=agreement_date,
            effective_date=effective_date,
            start_date=start_date,
            end_date=end_date,
        )

        try:
            raw_text = ""
            if self._sdk_type == "google-genai":
                # Try primary model and common fallbacks
                models_to_try = [self.model_name, "gemini-flash-latest", "gemini-3.5-flash", "gemini-3.1-pro-preview", "gemini-3.8-flash"]
                last_err = None
                for model in dict.fromkeys(models_to_try):  # preserve order without duplicates
                    try:
                        response = self._client.models.generate_content(
                            model=model,
                            contents=prompt,
                        )
                        if response and response.text:
                            raw_text = response.text
                            break
                    except Exception as err:
                        last_err = err
                        logger.warning(f"Model {model} failed, trying next: {err}")
                if not raw_text:
                    raise last_err or Exception("Empty response from Gemini API.")

            elif self._sdk_type == "google-generativeai":
                response = self._client.generate_content(prompt)
                if response and response.text:
                    raw_text = response.text
                else:
                    raise Exception("Empty response from Gemini API.")
            else:
                raise GeminiAPIError("No Gemini client available.")

            # Sanitize output
            cleaned_text = sanitize_text(raw_text)
            return cleaned_text

        except MissingAPIKeyError:
            raise
        except Exception as e:
            error_str = str(e)
            logger.error(f"Gemini generation error: {error_str}")
            if "API_KEY_INVALID" in error_str or "api key not valid" in error_str.lower():
                raise GeminiAPIError("The provided Gemini API key is invalid or unauthorized. Please check your GEMINI_API_KEY.")
            elif "quota" in error_str.lower() or "resource_exhausted" in error_str.lower():
                raise GeminiAPIError("Gemini API rate limit or quota exceeded. Please wait a moment or check your API quota.")
            else:
                raise GeminiAPIError(f"Gemini API request failed: {error_str}")
