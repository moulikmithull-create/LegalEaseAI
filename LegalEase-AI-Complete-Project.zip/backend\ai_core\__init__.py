"""LegalEase AI Core Package"""
