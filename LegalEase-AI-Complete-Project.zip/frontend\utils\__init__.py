"""LegalEase Frontend Utils Package"""
