"""LegalEase Services Package"""
