"""
LegalEase AI - Smart Input Form Component
Renders intuitive form controls with smart contract templates, date pickers, and branding.
"""

from datetime import date, timedelta
from typing import Dict, Any, Optional
import streamlit as st
from backend.config import SUPPORTED_DOC_TYPES
from backend.utils.validation import validate_logo_file

# Smart Presets for quick drafting
SMART_PRESETS = {
    "Employment Contract": {
        "parties": "Employer: Apex Technologies Pvt. Ltd., having its principal office at Tech Park, Bengaluru, India\nEmployee: John Doe, residing at 123 Palm Grove, Indiranagar, Bengaluru, India",
        "terms": "Annual Compensation of ₹12,00,000 paid in equal monthly installments;\nWorking hours: 40 hours per week Monday through Friday;\nNotice Period: 30 calendar days written notice required for termination by either party;\nStandard non-disclosure and intellectual property assignment covenants apply;\nProbationary period of 3 months from the Effective Date"
    },
    "Non-Disclosure Agreement": {
        "parties": "Disclosing Party: TechNova Solutions LLC, 100 Innovation Way, San Francisco, CA\nReceiving Party: Quantum Software Corp, 200 Enterprise Blvd, Austin, TX",
        "terms": "Confidential Information encompasses all technical data, trade secrets, proprietary algorithms, and source code;\nNon-disclosure obligation shall remain in full effect for 3 years from the Effective Date;\nReceiving Party agrees to exercise reasonable degree of care to prevent unauthorized dissemination;\nExclusions apply to information already in the public domain without breach;\nDisputes shall be governed by the laws of the State of California"
    },
    "Lease Agreement": {
        "parties": "Landlord: Robert Smith, residing at 45 Meadow Lane, New York, NY\nTenant: Sarah Jenkins, residing at 78 Elm Street, Brooklyn, NY",
        "terms": "Monthly rent of $2,400 payable on the 1st business day of each calendar month;\nSecurity deposit of $2,400 deposited with Landlord prior to move-in;\nLease term duration of 12 months with option to renew upon 60 days written notice;\nTenant is responsible for standard interior maintenance and utilities;\nNo subletting permitted without prior written consent from Landlord"
    },
    "Service Agreement": {
        "parties": "Client: Global Retail Enterprises Inc., 500 Commerce St, Chicago, IL\nService Provider: Agile Cloud Solutions LLC, 750 Tech Hub Dr, Seattle, WA",
        "terms": "Total project fee of $35,000 billed on verified milestone delivery schedule;\nProvider agrees to deliver comprehensive cloud migration services as detailed in Statement of Work;\nInvoices payable net 30 days from presentation;\nMutual confidentiality and standard professional liability limits apply;\nEither party may terminate for material breach with 15 days cure notice"
    },
    "Freelance Contract": {
        "parties": "Client: Stellar Marketing Studio, 12 Creative Ave, Los Angeles, CA\nContractor: Jane Doe (Independent UI/UX Designer), Mumbai, India",
        "terms": "Fixed project fee of ₹85,000 with 50% advance deposit upon agreement execution;\nDeliverables include complete mobile app Figma design system and interactive prototype by agreed deadline;\nAll intellectual property transfers to Client upon receipt of final invoice settlement;\nIncludes up to two rounds of design revisions;\nIndependent contractor status without employee benefits"
    },
    "Partnership Agreement": {
        "parties": "Partner 1: Alex Morgan (50% Equity & Managing Partner), London, UK\nPartner 2: David Chen (50% Equity & Technical Partner), London, UK",
        "terms": "Capital contribution of £25,000 by each partner at formation;\nProfit and loss distribution allocated strictly proportional to 50/50 equity shares;\nMajor operational and capital expenditure decisions require unanimous mutual consent;\nDispute resolution through binding professional commercial arbitration;\nBuyout rights triggered upon retirement or withdrawal notice of 90 days"
    },
    "Sales Agreement": {
        "parties": "Seller: Precision Machinery Corp, Industrial Area, Pune, India\nBuyer: Horizon Manufacturing Ltd, Auto Hub, Chennai, India",
        "terms": "Total purchase price of ₹18,50,000 for specified industrial CNC equipment;\nPayment schedule: 30% advance on order, 70% against delivery and operational inspection;\nSeller provides 12 months comprehensive warranty against manufacturing defects;\nDelivery to be completed within 45 days of advance payment receipt;\nRisk of loss transfers upon delivery to Buyer's facility"
    },
    "General Agreement": {
        "parties": "First Party: Alpha Operations Inc., 100 Main Street, Boston, MA\nSecond Party: Omega Logistics Group, 200 Harbor Way, Boston, MA",
        "terms": "Mutual collaboration to streamline regional logistics and fulfillment operations;\nAgreement effective for initial term of 1 year, automatically renewable;\nEach party retains ownership of its pre-existing intellectual property;\nStrict confidentiality and non-solicitation of employees during the term and for 1 year thereafter;\nGoverned by the laws of the Commonwealth of Massachusetts"
    }
}


def render_input_form() -> Optional[Dict[str, Any]]:
    """
    Renders the document generation input form with smart presets.
    """
    st.markdown("<div class='smart-card-title'>📄 1. Document Type & Configuration</div>", unsafe_allow_html=True)

    # 1. Document Type Dropdown
    selected_doc_type = st.selectbox(
        "Document Category",
        options=SUPPORTED_DOC_TYPES,
        index=0,
        help="Select the contractual category. Smart legal presets will adjust automatically."
    )

    preset = SMART_PRESETS.get(selected_doc_type, SMART_PRESETS["Employment Contract"])

    # Track selection changes to auto-suggest smart presets
    if st.session_state.get("prev_selected_doc_type") != selected_doc_type:
        st.session_state["prev_selected_doc_type"] = selected_doc_type
        st.session_state["parties_input"] = preset["parties"]
        st.session_state["terms_input"] = preset["terms"]

    # 2. Parties Involved Text Area
    parties_input = st.text_area(
        "Parties Involved",
        value=st.session_state.get("parties_input", preset["parties"]),
        height=95,
        placeholder="Enter names, roles, addresses, and corporate status of all parties...",
        help="Specify Party 1, Party 2, and their legal capacities (e.g. Employer/Employee, Landlord/Tenant, Client/Contractor)."
    )

    # 3. Terms & Conditions
    terms_input = st.text_area(
        "Key Terms & Conditions (Separate distinct clauses with semicolons ';')",
        value=st.session_state.get("terms_input", preset["terms"]),
        height=125,
        placeholder="Payment amount: $50,000; Notice period: 30 days; Confidentiality applies...",
        help="Each semicolon creates a distinct contractual clause and populates the auto-generated Schedule A Terms Table."
    )

    # 4. Dates Selection
    st.markdown("<div class='smart-card-title' style='margin-top: 15px;'>📅 2. Agreement Dates</div>", unsafe_allow_html=True)
    today = date.today()
    col1, col2 = st.columns(2)
    with col1:
        agreement_date = st.date_input(
            "Agreement Date",
            value=today,
            help="The date when this agreement is formally signed."
        )
        start_date = st.date_input(
            "Start Date (Optional)",
            value=today,
            help="The date when obligations begin."
        )

    with col2:
        effective_date = st.date_input(
            "Effective Date",
            value=today,
            help="The date when the agreement becomes legally enforceable."
        )
        end_date = st.date_input(
            "End Date (Optional)",
            value=today + timedelta(days=365),
            help="The expiration or renewal deadline for the contract."
        )

    # 5. Optional Branding Logo
    st.markdown("<div class='smart-card-title' style='margin-top: 15px;'>🏢 3. Custom Branding (Optional)</div>", unsafe_allow_html=True)
    uploaded_logo = st.file_uploader(
        "Upload Organization Logo",
        type=["png", "jpg", "jpeg", "webp"],
        help="Upload a company logo to embed in headers, DOCX, and PDF exports. Defaults to LegalEase branding if empty."
    )

    if uploaded_logo is not None:
        raw_bytes = uploaded_logo.read()
        is_valid, err_msg = validate_logo_file(raw_bytes)
        if is_valid:
            st.session_state["custom_logo_bytes"] = raw_bytes
            st.success("Logo uploaded and validated successfully!")
            st.image(raw_bytes, width=140)
        else:
            st.error(f"Logo validation error: {err_msg}")

    # 6. Generate Action
    st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
    generate_clicked = st.button(
        "✨ Generate Legal Document",
        type="primary",
        help="Synthesize terms into a comprehensive legal contract."
    )

    if generate_clicked:
        if not parties_input.strip():
            st.error("Please enter the parties involved in the agreement.")
            return None

        clean_terms = [t.strip() for t in terms_input.replace("\n", ";").split(";") if t.strip()]
        if not clean_terms:
            st.error("Please provide at least one key term or condition.")
            return None

        if end_date < start_date:
            st.error(f"Invalid date range: End date ({end_date}) cannot precede Start date ({start_date}).")
            return None

        payload = {
            "document_type": selected_doc_type,
            "parties": parties_input.strip(),
            "terms": clean_terms,
            "agreement_date": agreement_date.strftime("%Y-%m-%d"),
            "effective_date": effective_date.strftime("%Y-%m-%d"),
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
        }

        st.session_state["parties_input"] = parties_input
        st.session_state["terms_input"] = terms_input
        st.session_state["document_type"] = selected_doc_type
        st.session_state["parsed_terms"] = clean_terms

        return payload

    return None
