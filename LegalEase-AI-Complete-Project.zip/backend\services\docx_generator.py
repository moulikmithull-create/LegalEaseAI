"""
LegalEase AI - Microsoft Word (DOCX) Document Formatter
"""

import io
import os
from typing import List, Optional, Union
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

from backend.config import DEFAULT_LOGO_PATH, LEGAL_DISCLAIMER
from backend.utils.sanitization import parse_terms_to_table_data


def set_cell_background(cell, fill_hex: str):
    """Sets background shading of a docx table cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    """Sets cell padding in dxa (1 pt = 20 dxa)."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for margin_name, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{margin_name}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)


def format_docx(
    text: str,
    doc_type: str = "Legal Document",
    terms: Optional[List[str]] = None,
    logo_bytes: Optional[bytes] = None,
) -> bytes:
    """
    Converts legal document text and metadata into a beautifully styled DOCX file.
    Includes:
    - Branded logo at top
    - Centered Document Title
    - Times New Roman font styling
    - Structured paragraphs and bold section headers
    - Terms table with custom shading
    - Formal signature blocks
    - Footer with page numbers and legal disclaimer
    """
    doc = Document()

    # Configure Margins (1 inch all around)
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

        # Configure Header & Footer
        footer = section.footer
        footer_p = footer.paragraphs[0]
        footer_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        footer_run = footer_p.add_run(
            f"LegalEase Inc. | contact@legalease.com | All Rights Reserved.\n{LEGAL_DISCLAIMER}"
        )
        footer_run.font.name = "Times New Roman"
        footer_run.font.size = Pt(8.5)
        footer_run.font.italic = True
        footer_run.font.color.rgb = RGBColor(120, 120, 120)

    # 1. Embed Logo if available
    logo_stream = None
    if logo_bytes:
        logo_stream = io.BytesIO(logo_bytes)
    elif os.path.exists(DEFAULT_LOGO_PATH):
        try:
            with open(DEFAULT_LOGO_PATH, "rb") as f:
                logo_stream = io.BytesIO(f.read())
        except Exception:
            logo_stream = None

    if logo_stream:
        try:
            logo_p = doc.add_paragraph()
            logo_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            logo_run = logo_p.add_run()
            logo_run.add_picture(logo_stream, width=Inches(1.8))
        except Exception:
            pass  # Fall back gracefully if logo image format fails

    # 2. Document Title
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(8)
    title_p.paragraph_format.space_after = Pt(16)
    title_run = title_p.add_run(doc_type.upper())
    title_run.font.name = "Times New Roman"
    title_run.font.size = Pt(18)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(15, 23, 42)

    # 3. Main Document Body Formatting
    raw_lines = text.strip().split("\n")
    i = 0
    in_signature_block = False

    while i < len(raw_lines):
        line = raw_lines[i].strip()
        if not line:
            i += 1
            continue

        # Check for Headings
        is_h1 = line.startswith("# ") or (line.isupper() and len(line) < 60 and not line.startswith("IN WITNESS"))
        is_h2 = line.startswith("## ") or (
            any(line.startswith(f"{num}.") or line.startswith(f"SECTION {num}") or line.startswith(f"ARTICLE {num}") for num in range(1, 30))
            and len(line) < 80
        )
        is_h3 = line.startswith("### ")

        # Strip markdown markers if present
        clean_line = line.lstrip("#").strip()

        # Detect Signatures section
        if "SIGNATURE" in clean_line.upper() or "IN WITNESS WHEREOF" in clean_line.upper():
            in_signature_block = True

        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.15

        if is_h1:
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
            run = p.add_run(clean_line)
            run.font.name = "Times New Roman"
            run.font.size = Pt(14)
            run.font.bold = True
            run.font.color.rgb = RGBColor(20, 35, 60)
        elif is_h2:
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(4)
            run = p.add_run(clean_line)
            run.font.name = "Times New Roman"
            run.font.size = Pt(12)
            run.font.bold = True
            run.font.color.rgb = RGBColor(30, 41, 59)
        elif is_h3:
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(2)
            run = p.add_run(clean_line)
            run.font.name = "Times New Roman"
            run.font.size = Pt(11)
            run.font.bold = True
            run.font.color.rgb = RGBColor(51, 65, 85)
        else:
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(6)
            # Indent numbered legal sub-clauses
            if clean_line.startswith("(") and len(clean_line) > 3 and clean_line[2] == ")":
                p.paragraph_format.left_indent = Inches(0.25)
            elif clean_line.startswith("- ") or clean_line.startswith("* "):
                p.paragraph_format.left_indent = Inches(0.25)
                clean_line = "• " + clean_line[2:]

            run = p.add_run(clean_line)
            run.font.name = "Times New Roman"
            run.font.size = Pt(11)
            run.font.color.rgb = RGBColor(33, 37, 41)

        i += 1

    # 4. Auto-generate Terms Table if structured terms are available
    if terms and len(terms) > 0:
        table_heading_p = doc.add_paragraph()
        table_heading_p.paragraph_format.space_before = Pt(18)
        table_heading_p.paragraph_format.space_after = Pt(6)
        th_run = table_heading_p.add_run("SCHEDULE A: KEY AGREEMENT TERMS")
        th_run.font.name = "Times New Roman"
        th_run.font.size = Pt(12)
        th_run.font.bold = True
        th_run.font.color.rgb = RGBColor(20, 35, 60)

        table_data = parse_terms_to_table_data(terms)
        table = doc.add_table(rows=1, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False

        # Header Row
        hdr_cells = table.rows[0].cells
        hdr_cells[0].width = Inches(2.2)
        hdr_cells[1].width = Inches(4.3)
        hdr_cells[0].text = "Agreed Term / Provision"
        hdr_cells[1].text = "Specific Terms & Conditions"

        for cell in hdr_cells:
            set_cell_background(cell, "1E293B")  # Dark slate navy
            set_cell_margins(cell, top=140, bottom=140, left=180, right=180)
            for paragraph in cell.paragraphs:
                for r in paragraph.runs:
                    r.font.name = "Times New Roman"
                    r.font.size = Pt(10)
                    r.font.bold = True
                    r.font.color.rgb = RGBColor(255, 255, 255)

        # Data Rows
        for idx, (term_col, details_col) in enumerate(table_data):
            row_cells = table.add_row().cells
            row_cells[0].width = Inches(2.2)
            row_cells[1].width = Inches(4.3)
            row_cells[0].text = term_col
            row_cells[1].text = details_col

            bg_color = "F8FAFC" if idx % 2 == 0 else "FFFFFF"
            for cell in row_cells:
                set_cell_background(cell, bg_color)
                set_cell_margins(cell, top=100, bottom=100, left=180, right=180)
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                for paragraph in cell.paragraphs:
                    for r in paragraph.runs:
                        r.font.name = "Times New Roman"
                        r.font.size = Pt(10)
                        r.font.color.rgb = RGBColor(33, 37, 41)

    # 5. Add formal signature block if not explicitly generated
    if not in_signature_block:
        doc.add_paragraph().paragraph_format.space_before = Pt(20)
        sig_p = doc.add_paragraph()
        sig_p.paragraph_format.space_before = Pt(16)
        sig_p.paragraph_format.space_after = Pt(8)
        s_run = sig_p.add_run("IN WITNESS WHEREOF, the parties hereto have executed this Agreement:")
        s_run.font.name = "Times New Roman"
        s_run.font.size = Pt(11)
        s_run.font.bold = True

        sig_table = doc.add_table(rows=1, cols=2)
        sig_table.alignment = WD_TABLE_ALIGNMENT.CENTER
        c1, c2 = sig_table.rows[0].cells
        c1.width = Inches(3.2)
        c2.width = Inches(3.2)

        c1.text = "FOR FIRST PARTY:\n\n___________________________________\nSignature\n\nName: _____________________________\nTitle: ______________________________\nDate: ______________________________"
        c2.text = "FOR SECOND PARTY:\n\n___________________________________\nSignature\n\nName: _____________________________\nTitle: ______________________________\nDate: ______________________________"

        for cell in (c1, c2):
            for paragraph in cell.paragraphs:
                for r in paragraph.runs:
                    r.font.name = "Times New Roman"
                    r.font.size = Pt(9.5)

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()
