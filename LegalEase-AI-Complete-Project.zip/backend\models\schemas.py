"""
LegalEase AI - Pydantic Schemas for Request and Response Validation
"""

from datetime import date, datetime
from typing import List, Optional, Union
from pydantic import BaseModel, Field, field_validator, model_validator


class DocumentRequest(BaseModel):
    """
    Validation schema for document generation requests.
    Supports structured terms list or semicolon-separated string.
    """
    document_type: str = Field(
        ...,
        description="Type of legal document (e.g., Employment Contract, Non-Disclosure Agreement)"
    )
    parties: str = Field(
        ...,
        description="Parties involved in the agreement with names and roles"
    )
    terms: Union[List[str], str] = Field(
        ...,
        description="Key terms and conditions. Can be a list of strings or semicolon-separated string"
    )
    agreement_date: str = Field(
        ...,
        description="Date of agreement execution (YYYY-MM-DD or readable date string)"
    )
    effective_date: str = Field(
        ...,
        description="Date when agreement becomes effective (YYYY-MM-DD or readable date string)"
    )
    start_date: Optional[str] = Field(
        None,
        description="Optional start date of agreement/term"
    )
    end_date: Optional[str] = Field(
        None,
        description="Optional end date of agreement/term"
    )

    @field_validator("document_type")
    @classmethod
    def validate_document_type(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError("Document type cannot be empty.")
        if len(cleaned) < 3:
            raise ValueError("Document type is too short.")
        return cleaned

    @field_validator("parties")
    @classmethod
    def validate_parties(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError("Parties field cannot be empty.")
        if len(cleaned) < 5:
            raise ValueError("Parties description is too short; please specify entities or individuals.")
        return cleaned

    @field_validator("terms")
    @classmethod
    def validate_terms(cls, v: Union[List[str], str]) -> List[str]:
        if isinstance(v, str):
            # Parse semicolon-separated terms or newline-separated
            raw_clauses = [t.strip() for t in v.replace("\n", ";").split(";") if t.strip()]
        elif isinstance(v, list):
            raw_clauses = [str(t).strip() for t in v if str(t).strip()]
        else:
            raise ValueError("Terms must be a list of strings or a semicolon-separated string.")

        if not raw_clauses:
            raise ValueError("Terms must contain at least one meaningful clause.")

        return raw_clauses

    @field_validator("agreement_date", "effective_date")
    @classmethod
    def validate_required_dates(cls, v: str, info) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError(f"{info.field_name.replace('_', ' ').capitalize()} cannot be empty.")
        return cleaned

    @model_validator(mode="after")
    def validate_date_order(self):
        """Ensure that end_date is not prior to start_date when both are parseable dates."""
        start_val = self.start_date.strip() if self.start_date else None
        end_val = self.end_date.strip() if self.end_date else None

        if start_val and end_val:
            parsed_start = cls_parse_date(start_val)
            parsed_end = cls_parse_date(end_val)

            if parsed_start and parsed_end:
                if parsed_end < parsed_start:
                    raise ValueError(f"End date ({end_val}) cannot be before start date ({start_val}).")

        return self


def cls_parse_date(date_str: str) -> Optional[date]:
    """Helper to parse common date formats for validation."""
    formats = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%B %d, %Y",
        "%d %B %Y",
        "%b %d, %Y",
        "%d-%m-%Y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str.strip(), fmt).date()
        except (ValueError, TypeError):
            continue
    return None


class DocumentResponse(BaseModel):
    """
    Standardized response returned by /generate endpoint.
    """
    success: bool = True
    document_type: str
    content: str
    error: Optional[str] = None
    terms_count: Optional[int] = 0


class HealthResponse(BaseModel):
    """
    Response schema for /health endpoint.
    """
    status: str = "healthy"
    model_configured: Optional[str] = None
    api_key_configured: bool = False
