"""
LegalEase AI - Input and Date Validation Tests
"""

import pytest
from pydantic import ValidationError
from backend.models.schemas import DocumentRequest
from backend.utils.validation import validate_document_input, validate_logo_file


def test_valid_document_request():
    """Verify standard document request passes validation."""
    payload = {
        "document_type": "Employment Contract",
        "parties": "Employer: ABC Corp\nEmployee: Jane Doe",
        "terms": ["Salary: $60,000", "Notice period: 30 days"],
        "agreement_date": "2026-10-03",
        "effective_date": "2026-10-05",
        "start_date": "2026-10-05",
        "end_date": "2027-10-05",
    }
    req = DocumentRequest(**payload)
    assert req.document_type == "Employment Contract"
    assert len(req.terms) == 2


def test_semicolon_string_terms_parsing():
    """Verify semicolon-separated string terms parse into structured list."""
    payload = {
        "document_type": "Non-Disclosure Agreement",
        "parties": "Discloser: Corp A; Recipient: Corp B",
        "terms": "Confidentiality lasts 3 years; Permitted use only for evaluation; Return data upon demand",
        "agreement_date": "2026-10-03",
        "effective_date": "2026-10-05",
    }
    req = DocumentRequest(**payload)
    assert isinstance(req.terms, list)
    assert len(req.terms) == 3


def test_missing_document_type():
    """Validation must fail if document_type is empty."""
    with pytest.raises(ValidationError):
        DocumentRequest(
            document_type="",
            parties="Party A and Party B",
            terms=["Payment: $1000"],
            agreement_date="2026-10-03",
            effective_date="2026-10-05",
        )


def test_missing_parties():
    """Validation must fail if parties field is empty."""
    with pytest.raises(ValidationError):
        DocumentRequest(
            document_type="Service Agreement",
            parties="",
            terms=["Service fee: $500"],
            agreement_date="2026-10-03",
            effective_date="2026-10-05",
        )


def test_invalid_date_order():
    """Validation must fail when end_date precedes start_date."""
    with pytest.raises(ValidationError):
        DocumentRequest(
            document_type="Lease Agreement",
            parties="Landlord: A, Tenant: B",
            terms=["Rent: $1,200/mo"],
            agreement_date="2026-10-03",
            effective_date="2026-10-05",
            start_date="2026-10-05",
            end_date="2026-09-01",  # Prior to start date
        )


def test_validate_document_input_helper():
    """Test the standalone input validation helper function."""
    valid, err = validate_document_input(
        document_type="Sales Agreement",
        parties="Buyer: X, Seller: Y",
        terms=["Price: $50,000"],
        agreement_date="2026-10-03",
        effective_date="2026-10-05",
    )
    assert valid is True
    assert err is None

    invalid, err = validate_document_input(
        document_type="",
        parties="Buyer: X, Seller: Y",
        terms=["Price: $50,000"],
        agreement_date="2026-10-03",
        effective_date="2026-10-05",
    )
    assert invalid is False
    assert "Document type is required" in err


def test_validate_logo_file():
    """Test logo validation for empty and invalid files."""
    valid, err = validate_logo_file(b"")
    assert valid is False

    valid, err = validate_logo_file(b"not an image file")
    assert valid is False
