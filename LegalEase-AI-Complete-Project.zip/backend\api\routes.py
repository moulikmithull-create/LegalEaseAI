"""
LegalEase AI - Core API Routes
Handles /generate and document processing endpoints.
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import Response

from backend.models.schemas import DocumentRequest, DocumentResponse
from backend.services.document_service import DocumentService
from backend.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.utils.error_handler import LegalEaseException

router = APIRouter(tags=["Document Generation"])

# Initialize Document Service singleton
_doc_service = DocumentService(GeminiDocumentGenerator())


def get_document_service() -> DocumentService:
    return _doc_service


@router.post("/generate", response_model=DocumentResponse, summary="Generate Legal Document")
def generate_legal_document(
    request: DocumentRequest,
    doc_service: DocumentService = Depends(get_document_service)
) -> DocumentResponse:
    """
    Accepts document type, parties, terms, and dates to generate a structured
    legal agreement draft using Google Gemini AI.
    """
    try:
        response = doc_service.generate(request)
        return response
    except LegalEaseException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
