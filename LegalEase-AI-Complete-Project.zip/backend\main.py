"""
LegalEase AI - FastAPI Backend Application Entrypoint
"""

import sys
from pathlib import Path

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from backend.config import BACKEND_HOST, BACKEND_PORT
from backend.api.routes import router as generate_router
from backend.api.health import router as health_router
from backend.utils.error_handler import (
    LegalEaseException,
    legal_ease_exception_handler,
    global_exception_handler,
)

app = FastAPI(
    title="LegalEase - AI Legal Document Generator",
    description="Automated legal document drafting and formatting platform powered by Google Gemini AI.",
    version="1.0.0",
)

# Enable CORS for frontend clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register Exception Handlers
app.add_exception_handler(LegalEaseException, legal_ease_exception_handler)
app.add_exception_handler(Exception, global_exception_handler)

# Include API Routers
app.include_router(health_router)
app.include_router(generate_router)


if __name__ == "__main__":
    uvicorn.run(
        "backend.main:app",
        host=BACKEND_HOST,
        port=BACKEND_PORT,
        reload=True,
    )
