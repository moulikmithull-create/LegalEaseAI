"""
LegalEase AI - Configuration Settings
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Base Directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Load environment variables
load_dotenv(BASE_DIR / ".env")

# API Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash").strip()
BACKEND_HOST = os.getenv("BACKEND_HOST", "0.0.0.0")
BACKEND_PORT = int(os.getenv("BACKEND_PORT", "8000"))
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000").rstrip("/")

# Assets Directory
ASSETS_DIR = BASE_DIR / "assets"
DEFAULT_LOGO_PATH = ASSETS_DIR / "logo.png"

# Allowed Document Types
SUPPORTED_DOC_TYPES = [
    "Employment Contract",
    "Lease Agreement",
    "Non-Disclosure Agreement",
    "Service Agreement",
    "Partnership Agreement",
    "Sales Agreement",
    "Freelance Contract",
    "General Agreement",
]

# Legal Disclaimer
LEGAL_DISCLAIMER = (
    "AI-generated document for drafting purposes only. "
    "This application does not provide legal advice. "
    "Review the generated document with a qualified legal professional before signing or using it."
)
