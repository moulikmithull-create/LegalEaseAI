"""
LegalEase AI - Unified Document Service
Coordinates AI drafting and multi-format document export (TXT, DOCX, PDF, HTML preview).
"""

import html
import re
from typing import List, Optional
from backend.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.models.schemas import DocumentRequest, DocumentResponse
from backend.services.txt_generator import format_txt
from backend.services.docx_generator import format_docx
from backend.services.pdf_generator import format_pdf
from backend.utils.sanitization import sanitize_text, parse_terms_to_table_data
from backend.config import LEGAL_DISCLAIMER


class DocumentService:
    """
    Central orchestration service for generating, formatting, and previewing
    LegalEase documents.
    """

    def __init__(self, generator: Optional[GeminiDocumentGenerator] = None):
        self.generator = generator or GeminiDocumentGenerator()

    def generate(self, request: DocumentRequest) -> DocumentResponse:
        """Generates legal document content using Gemini AI."""
        content = self.generator.generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            agreement_date=request.agreement_date,
            effective_date=request.effective_date,
            start_date=request.start_date,
            end_date=request.end_date,
        )

        terms_list = request.terms if isinstance(request.terms, list) else [
            t.strip() for t in request.terms.split(";") if t.strip()
        ]

        return DocumentResponse(
            success=True,
            document_type=request.document_type,
            content=content,
            terms_count=len(terms_list),
        )

    def export_as_txt(
        self,
        text: str,
        doc_type: str = "Legal Document",
        terms: Optional[List[str]] = None,
    ) -> bytes:
        """Export as clean UTF-8 text bytes."""
        return format_txt(text=text, doc_type=doc_type, terms=terms)

    def export_as_docx(
        self,
        text: str,
        doc_type: str = "Legal Document",
        terms: Optional[List[str]] = None,
        logo_bytes: Optional[bytes] = None,
    ) -> bytes:
        """Export as Microsoft Word DOCX bytes."""
        return format_docx(text=text, doc_type=doc_type, terms=terms, logo_bytes=logo_bytes)

    def export_as_pdf(
        self,
        text: str,
        doc_type: str = "Legal Document",
        terms: Optional[List[str]] = None,
        logo_bytes: Optional[bytes] = None,
    ) -> bytes:
        """Export as styled PDF bytes."""
        return format_pdf(text=text, doc_type=doc_type, terms=terms, logo_bytes=logo_bytes)

    @staticmethod
    def format_html_preview(
        text: str,
        doc_type: str = "Legal Document",
        terms: Optional[List[str]] = None,
        logo_data_uri: Optional[str] = None,
    ) -> str:
        """
        Converts legal document draft into a high-resolution, full-size, readable HTML paper view.
        No indentation on any lines to prevent Markdown code block glitches.
        """
        escaped_title = html.escape(doc_type.upper())
        lines = text.strip().split("\n")

        body_html_parts = []
        for line in lines:
            trimmed = line.strip()
            if not trimmed:
                body_html_parts.append("<div style='height: 12px;'></div>")
                continue

            escaped = html.escape(trimmed)

            if trimmed.startswith("# "):
                heading_text = html.escape(trimmed.lstrip("#").strip())
                body_html_parts.append(
                    f"<h3 style='color: #0f172a; margin-top: 24px; margin-bottom: 10px; font-weight: 800; "
                    f"border-bottom: 2px solid #0284c7; padding-bottom: 6px; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; font-size: 17px; letter-spacing: 0.3px;'>{heading_text}</h3>"
                )
            elif trimmed.startswith("## "):
                heading_text = html.escape(trimmed.lstrip("#").strip())
                body_html_parts.append(
                    f"<h4 style='color: #1e3a8a; margin-top: 20px; margin-bottom: 8px; font-weight: 700; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; font-size: 15px;'>{heading_text}</h4>"
                )
            elif trimmed.startswith("### "):
                heading_text = html.escape(trimmed.lstrip("#").strip())
                body_html_parts.append(
                    f"<h5 style='color: #334155; margin-top: 16px; margin-bottom: 6px; font-weight: 700; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; font-size: 14px;'>{heading_text}</h5>"
                )
            elif any(trimmed.startswith(f"{n}.") for n in range(1, 30)) and len(trimmed) < 80:
                body_html_parts.append(
                    f"<h4 style='color: #0f172a; margin-top: 18px; margin-bottom: 8px; font-weight: 700; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; font-size: 15px;'>{escaped}</h4>"
                )
            elif trimmed.startswith("- ") or trimmed.startswith("* "):
                bullet_content = html.escape(trimmed[2:])
                body_html_parts.append(
                    f"<div style='margin-left: 24px; margin-bottom: 8px; color: #1e293b; font-size: 14.5px; line-height: 1.7;'>"
                    f"<span style='color: #0284c7; margin-right: 10px; font-weight: bold;'>&bull;</span>{bullet_content}</div>"
                )
            else:
                body_html_parts.append(
                    f"<p style='margin: 0 0 12px 0; color: #1e293b; line-height: 1.75; text-align: justify; font-size: 14.5px;'>{escaped}</p>"
                )

        body_html = "\n".join(body_html_parts)

        # Build Terms Table HTML
        terms_table_html = ""
        if terms and len(terms) > 0:
            parsed_terms = parse_terms_to_table_data(terms)
            rows_html = []
            for idx, (term_name, details) in enumerate(parsed_terms):
                bg = "#f8fafc" if idx % 2 == 0 else "#ffffff"
                rows_html.append(
                    f"<tr style='background-color: {bg};'>"
                    f"<td style='padding: 12px 16px; border: 1px solid #cbd5e1; font-weight: 700; color: #0f172a; width: 35%; font-size: 14px;'>{html.escape(term_name)}</td>"
                    f"<td style='padding: 12px 16px; border: 1px solid #cbd5e1; color: #334155; font-size: 14px; line-height: 1.6;'>{html.escape(details)}</td>"
                    f"</tr>"
                )
            rows_joined = "".join(rows_html)

            terms_table_html = (
                "<div style='margin-top: 30px; margin-bottom: 24px;'>"
                "<h4 style='color: #0f172a; margin-bottom: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; font-size: 15px;'>"
                "Schedule A: Summary of Agreed Key Terms"
                "</h4>"
                "<table style='width: 100%; border-collapse: collapse; font-size: 14px; border-radius: 6px; overflow: hidden; border: 1px solid #cbd5e1;'>"
                "<thead>"
                "<tr style='background-color: #0f172a; color: #ffffff;'>"
                "<th style='padding: 12px 16px; border: 1px solid #334155; text-align: left; font-weight: 700; font-size: 14px;'>Agreed Provision</th>"
                "<th style='padding: 12px 16px; border: 1px solid #334155; text-align: left; font-weight: 700; font-size: 14px;'>Term Specification / Details</th>"
                "</tr>"
                "</thead>"
                f"<tbody>{rows_joined}</tbody>"
                "</table>"
                "</div>"
            )

        logo_img_tag = ""
        if logo_data_uri:
            logo_img_tag = f"<div style='text-align: center; margin-bottom: 20px;'><img src='{logo_data_uri}' style='max-height: 60px; max-width: 250px; object-fit: contain;' /></div>"

        # High-res, full width document viewer paper styling
        full_html = (
            "<div class='legalease-preview-container document-viewer' style='"
            "background-color: #ffffff; "
            "color: #0f172a; "
            "border: 1px solid #cbd5e1; "
            "border-radius: 10px; "
            "padding: 40px 48px; "
            "font-family: Georgia, 'Times New Roman', serif; "
            "min-height: 500px; "
            "max-height: 650px; "
            "overflow-y: auto; "
            "width: 100%; "
            "box-sizing: border-box; "
            "box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);'>"
            f"{logo_img_tag}"
            "<div style='text-align: center; margin-bottom: 26px; border-bottom: 2px solid #0284c7; padding-bottom: 14px;'>"
            f"<h2 style='color: #0f172a; margin: 0 0 8px 0; font-size: 24px; font-weight: 800; letter-spacing: 0.5px; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;'>{escaped_title}</h2>"
            "<div style='font-size: 13px; color: #0284c7; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;'>LegalEase AI Formatted Draft</div>"
            "</div>"
            f"<div>{body_html}</div>"
            f"{terms_table_html}"
            "<div style='margin-top: 36px; padding-top: 16px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 12px; color: #64748b; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;'>"
            f"<div><strong>Legal Notice:</strong> {html.escape(LEGAL_DISCLAIMER)}</div>"
            "<div style='margin-top: 6px;'>LegalEase Inc. | contact@legalease.com | All Rights Reserved.</div>"
            "</div>"
            "</div>"
        )

        return full_html
