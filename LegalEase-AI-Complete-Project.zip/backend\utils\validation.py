"""
LegalEase AI - Input and Asset Validation Utilities
"""

from datetime import date, datetime
from typing import List, Optional, Tuple
import io
from PIL import Image


def validate_document_input(
    document_type: str,
    parties: str,
    terms: List[str],
    agreement_date: str,
    effective_date: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """
    Validate all inputs before passing to generator.
    Returns (is_valid, error_message).
    """
    if not document_type or not document_type.strip():
        return False, "Document type is required and cannot be empty."

    if not parties or not parties.strip():
        return False, "Parties involved must be specified."

    if not terms or len(terms) == 0:
        return False, "At least one term or condition must be provided."

    if not agreement_date or not agreement_date.strip():
        return False, "Agreement date is required."

    if not effective_date or not effective_date.strip():
        return False, "Effective date is required."

    if start_date and end_date and start_date.strip() and end_date.strip():
        parsed_start = parse_date_str(start_date)
        parsed_end = parse_date_str(end_date)
        if parsed_start and parsed_end:
            if parsed_end < parsed_start:
                return False, f"End date ({end_date}) cannot precede Start date ({start_date})."

    return True, None


def parse_date_str(val: str) -> Optional[date]:
    """Parse various common date strings."""
    formats = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%B %d, %Y",
        "%d %B %Y",
        "%b %d, %Y",
        "%d-%m-%Y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(val.strip(), fmt).date()
        except (ValueError, TypeError):
            continue
    return None


def validate_logo_file(file_bytes: bytes, max_size_mb: int = 5) -> Tuple[bool, Optional[str]]:
    """
    Validates uploaded logo bytes to ensure safe image file.
    """
    if not file_bytes:
        return False, "Empty file provided."

    if len(file_bytes) > max_size_mb * 1024 * 1024:
        return False, f"File size exceeds maximum allowed size of {max_size_mb}MB."

    try:
        image = Image.open(io.BytesIO(file_bytes))
        image.verify()  # Verify image integrity
        if image.format not in ["PNG", "JPEG", "JPG", "WEBP"]:
            return False, f"Unsupported image format: {image.format}. Please upload PNG or JPEG."
    except Exception as e:
        return False, f"Invalid image file: {str(e)}"

    return True, None
