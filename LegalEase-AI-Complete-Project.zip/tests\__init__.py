"""LegalEase Test Suite"""
