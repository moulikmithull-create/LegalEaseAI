"""
LegalEase AI - Export & Download Buttons Component
Renders download buttons for TXT, DOCX, and PDF formats.
"""

from typing import Optional, List
import streamlit as st
from backend.services.document_service import DocumentService


def render_download_buttons(
    content: str,
    doc_type: str,
    terms: Optional[List[str]] = None,
    logo_bytes: Optional[bytes] = None,
):
    """
    Renders export and download buttons for TXT, DOCX, and PDF.
    All exports use the latest edited text.
    """
    st.markdown("<div style='margin-top: 20px;'></div>", unsafe_allow_html=True)
    st.markdown("<div class='smart-card-title'>💾 Export & Download Final Document</div>", unsafe_allow_html=True)

    doc_service = DocumentService()
    active_text = st.session_state.get("edited_document") or content
    safe_base_name = doc_type.strip().lower().replace(" ", "_").replace("-", "_")

    col1, col2, col3 = st.columns(3)

    # 1. Plain Text (.txt)
    with col1:
        txt_bytes = doc_service.export_as_txt(
            text=active_text,
            doc_type=doc_type,
            terms=terms,
        )
        st.download_button(
            label="📄 Download .TXT",
            data=txt_bytes,
            file_name=f"{safe_base_name}.txt",
            mime="text/plain",
            help="Clean, UTF-8 formatted text draft."
        )

    # 2. Microsoft Word (.docx)
    with col2:
        try:
            docx_bytes = doc_service.export_as_docx(
                text=active_text,
                doc_type=doc_type,
                terms=terms,
                logo_bytes=logo_bytes,
            )
            st.download_button(
                label="📝 Download .DOCX",
                data=docx_bytes,
                file_name=f"{safe_base_name}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                help="Word document formatted in Times New Roman with logo, tables, and footer."
            )
        except Exception as e:
            st.error(f"DOCX preparation error: {e}")

    # 3. PDF (.pdf)
    with col3:
        try:
            pdf_bytes = doc_service.export_as_pdf(
                text=active_text,
                doc_type=doc_type,
                terms=terms,
                logo_bytes=logo_bytes,
            )
            st.download_button(
                label="📕 Download .PDF",
                data=pdf_bytes,
                file_name=f"{safe_base_name}.pdf",
                mime="application/pdf",
                help="Print-ready PDF with running headers, footers, logo, and numbered pages."
            )
        except Exception as e:
            st.error(f"PDF preparation error: {e}")
